package wc

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j.LogManager
import org.apache.log4j.Level
import java.io.PrintWriter

object PageRank {
  
  def main(args: Array[String]) {
    val logger: org.apache.log4j.Logger = LogManager.getRootLogger
    if (args.length != 3) {
      logger.error("Usage:\nwc.PageRank <k> <iter> <output dir>")
      System.exit(1)
    }
    val conf = new SparkConf().setAppName("Page Rank")
    val sc = new SparkContext(conf)

    // Taking input of params k and iter and converting to int
    val k = args(0).toInt
    val iter = args(1).toInt


    // Since a special synthetic graph is being created such that 
    // each node has at most 1 outgoing edge, the following approach is undertaken:
    // A list of numbers from 1 to k^2 is created. 
    // They are mapped to the next number or zero [if it's a dangling node]
    // Graph and ranks must have same partitioner to avoid shuffling during join
    // graph is cached as it won't be computed again  
    
    val partitioner = new org.apache.spark.HashPartitioner(k)

    val graph = sc.parallelize((1 to k*k).flatMap(i=>{
      if (i % k == 0) List((i,0))
      else List((i,i+1))
    })).partitionBy(partitioner).cache()

    var ranks = sc.parallelize((0 to k*k).flatMap(i=>{
      if (i == 0) List((i,0.0))
      else List(( i, 1.0/(k*k) ))
    })).partitionBy(partitioner).cache()

  // inner join graph and ranks to produces page rank of each node
  // however nodes having in-degree 0 are filtered output [1,4,7 for k=3]
  // they are  added to explicitly with rank 0
  // page rank of 0 is redistributed, its page rank is made 0

  for (i <- 1 to iter) {
   val joinedGraphRanks = graph.join(ranks).values
   val ranksExcludingFirstNodes = joinedGraphRanks.reduceByKey((a, b) => a + b)

   var firstNodes = sc.parallelize((1 to k).flatMap(i=>{
      List((1+k*(i-1),0.0))
    }))

    val allNodesRanks = ranksExcludingFirstNodes.union(firstNodes)

    val adjustedPROfzero = allNodesRanks.lookup(0).head/(k*k)
    ranks = allNodesRanks.flatMap{ case (node, rank) =>
        if (node==0) List((node,0.0))
        else List((node,rank+adjustedPROfzero))
      }.cache()

  }

  }
}